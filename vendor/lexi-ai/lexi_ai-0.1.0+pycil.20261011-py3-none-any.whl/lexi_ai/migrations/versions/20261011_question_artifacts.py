"""Replace the obsolete question pool; preserve every lexical table."""

from alembic import op

from lexi_ai.questions.positions import install_positions
from lexi_ai.schema import QuestionArtifact

revision = "20261011_artifacts"
down_revision = "20261010_no_notes"
branch_labels = None
depends_on = None


def upgrade():
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        for suffix in ("before", "after"):
            op.execute(f"DROP TRIGGER IF EXISTS lexi_positions_questions_{suffix} ON questions")
        op.execute("DROP FUNCTION IF EXISTS lexi_positions_questions()")
    op.drop_table("questions")
    QuestionArtifact.__table__.create(bind)
    install_positions(bind)


def downgrade():
    raise RuntimeError("Old question content was intentionally removed; restore a backup")
