"""Rename word-level reference links without changing lexical identities."""

from alembic import op

revision = "20261012_word_refs"
down_revision = "20261011_artifacts"
branch_labels = None
depends_on = None


def upgrade():
    op.rename_table("word_sources", "word_references")
    op.drop_index("ix_word_sources_word_id", table_name="word_references")
    op.create_index("ix_word_references_word_id", "word_references", ["word_id"])


def downgrade():
    op.drop_index("ix_word_references_word_id", table_name="word_references")
    op.rename_table("word_references", "word_sources")
    op.create_index("ix_word_sources_word_id", "word_sources", ["word_id"])
