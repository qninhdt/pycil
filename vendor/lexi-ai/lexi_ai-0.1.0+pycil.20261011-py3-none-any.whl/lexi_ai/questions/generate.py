"""One structured request per Sense/artifact bank, using existing provider limits."""

from pydantic import Field, create_model, model_validator
from sqlalchemy import select

from lexi_ai.errors import InvalidOutputError, InvalidResourceError, MissingProviderError
from lexi_ai.inference.prompting import render_prompt
from lexi_ai.models import QuestionArtifact
from lexi_ai.schema import Definition, Sense
from lexi_ai.vocab import SINGLETON_ARTIFACT_TYPES, QuestionArtifactType

from .schemas import ARTIFACT_SCHEMAS, Strict, validate_artifact
from .storage import append, bank_sizes, generation_context


async def generate_question_artifacts(
    db,
    llm,
    sense_id,
    artifact_type,
    batch_size=1,
    *,
    distractor_count=3,
    correct_count=1,
    theme_key=None,
):
    kind = QuestionArtifactType(artifact_type)
    if type(batch_size) is not int or not 1 <= batch_size <= 20:
        raise InvalidResourceError("Invalid artifact batch size")
    if any(type(v) is not int or not 0 <= v <= 20 for v in (correct_count, distractor_count)):
        raise InvalidResourceError("Invalid option count")
    singleton = kind in SINGLETON_ARTIFACT_TYPES
    if singleton:
        if not correct_count + distractor_count:
            raise InvalidResourceError("Request at least one new option")
        sizes = await bank_sizes(db, [(sense_id, kind)], theme_key=theme_key)
        if not sizes[sense_id, kind] and (correct_count == 0 or distractor_count == 0):
            raise InvalidResourceError("New singleton bank needs correct and distractor options")
    elif not 1 <= distractor_count <= 20:
        raise InvalidResourceError("Contextual artifacts need distractors")
    word, sense, theme = await generation_context(db, sense_id, theme_key=theme_key)
    if llm is None:
        raise MissingProviderError("Artifact generation requires a structured LLM")
    context = dict(
        word=word.lemma,
        pos=sense.pos,
        definition=sense.definition.content,
        distractor_count=distractor_count,
    )
    if singleton:
        context["correct_count"] = correct_count
    else:
        context["batch_size"] = batch_size
    if kind == QuestionArtifactType.WORD_DEFINITION:
        async with db.read() as connection:
            context["other_definitions"] = (
                await connection.scalars(
                    select(Definition.content)
                    .join(Sense, Sense.id == Definition.sense_id)
                    .where(
                        Sense.word_id == word.id,
                        Sense.id != sense.id,
                        Definition.theme_id == (theme["id"] if theme else None),
                    )
                )
            ).all()
    if kind in {
        QuestionArtifactType.WORD_TO_USAGE,
        QuestionArtifactType.CONTEXT_WORD_MEANING,
        QuestionArtifactType.DIALOGUE_COMPLETION,
        QuestionArtifactType.SENTENCE_REWRITE,
    }:
        if sense.forms:
            context["forms"] = [form.__dict__ for form in sense.forms]
        if sense.patterns:
            context["patterns"] = sense.patterns
    if kind == QuestionArtifactType.WORD_TO_USAGE and sense.collocations:
        context["collocations"] = sense.collocations
    if (
        kind in {QuestionArtifactType.WORD_TO_USAGE, QuestionArtifactType.DIALOGUE_COMPLETION}
        and sense.register
    ):
        context["register"] = sense.register
    if theme:
        context["theme"] = {k: theme[k] for k in ("voice", "diction")}
    instruction, data = render_prompt(
        "questions/prompts/generate_artifacts.jinja", artifact_type=kind, context=context
    )
    payload_schema = ARTIFACT_SCHEMAS[kind]

    def check(cls, values):
        raw = values.get("artifacts") if isinstance(values, dict) else None
        if not isinstance(raw, list):
            return values
        accepted = []
        for item in raw:
            try:
                payload = payload_schema.model_validate(item)
                validate_artifact(payload, kind, word, sense, distractor_count, correct_count)
            except ValueError, InvalidOutputError:
                continue
            accepted.append(payload.model_dump())
        if not accepted:
            raise ValueError("No usable artifacts")
        if singleton and len(accepted) != 1:
            raise ValueError("Singleton generation must return one increment")
        return dict(artifacts=accepted)

    output_schema = create_model(
        "ArtifactBatch",
        __base__=Strict,
        artifacts=(list[payload_schema], Field(min_length=1)),
        __validators__={"check": model_validator(mode="before")(classmethod(check))},
    )
    try:
        output = await llm.complete(instruction, data, output_schema)
        output = output_schema.model_validate(output)
    except ValueError as exc:
        raise InvalidOutputError("Invalid artifact batch") from exc
    return await append(
        db,
        [
            QuestionArtifact(0, sense_id, theme["id"] if theme else None, kind, item.model_dump())
            for item in output.artifacts
        ],
    )
