"""Stored answer-bearing QuestionArtifacts for trusted consumer servers."""
