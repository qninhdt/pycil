"""Two-stage diagnostic grading; sense identification never decides task fit."""

from types import SimpleNamespace

from sqlalchemy import select

from lexi_ai import schema as row
from lexi_ai.config import MAX_QUERY_LENGTH, MAX_TEXT_LENGTH
from lexi_ai.errors import (
    InvalidOutputError,
    InvalidResourceError,
    MissingProviderError,
    QuestionArtifactNotFoundError,
    UnsupportedQuestionFormatError,
)
from lexi_ai.inference.config import DecisionConfig, DecisionMode
from lexi_ai.inference.prompting import render_decision
from lexi_ai.models import DefinitionGrade, RewriteGrade, SingleWordGrade, UsageGrade
from lexi_ai.text import answer_key
from lexi_ai.vocab import (
    ALLOWED_PAIRS,
    QUESTION_ARTIFACT_MAP,
    DefinitionAccuracy,
    DefinitionCoverage,
    MeaningPreservation,
    QuestionType,
    ResponseFormat,
    UsageForm,
    UsageMeaning,
)
from lexi_ai.words.search import search
from lexi_ai.words.storage import meaning_inventory

from .storage import get as get_artifact

_PROMPTS = "questions/prompts/decision/"


def _selected_sense(response, name, senses):
    choice = response.choices[name].choice
    if choice == "no_candidate":
        return None
    by_key = {f"sense_{sense['id']}": sense for sense in senses}
    if choice not in by_key:
        raise InvalidOutputError("invalid decision sense")
    return by_key[choice]


async def _single_word(db, model, question, answer, config, options):
    response = await model.decide(
        *render_decision(
            _PROMPTS + "grade_single_word_1.json",
            question=question.content,
            question_type=question.question_type,
            answer=answer,
        ),
        **options,
    )
    task_fit = config.accepts(response.nouls["task_fit"].noul)
    spelling_error = config.accepts(response.nouls["spelling_error"].noul)
    if len(answer.strip()) > MAX_QUERY_LENGTH:
        return SingleWordGrade(task_fit, spelling_error, None)

    result = await search(db, answer, limit=1)
    if not result.items or not hasattr(result.items[0], "word_id"):
        return SingleWordGrade(task_fit, spelling_error, None)
    matched_word = await meaning_inventory(db, word_id=result.items[0].word_id)
    if matched_word is None or not matched_word["senses"]:
        return SingleWordGrade(task_fit, spelling_error, None)
    response = await model.decide(
        *render_decision(
            _PROMPTS + "grade_single_word_2.json",
            question=question.content,
            answer=answer,
            matched_word=matched_word,
        ),
        **options,
    )
    sense = _selected_sense(response, "matched_sense", matched_word["senses"])
    return SingleWordGrade(task_fit, spelling_error, sense["id"] if sense else None)


async def _definition(db, model, question, answer, options):
    word = await meaning_inventory(db, owner_of=question.sense_id)
    if word is None or not word["senses"]:
        raise InvalidResourceError("Artifact's Word has no published meaning inventory")
    response = await model.decide(
        *render_decision(
            _PROMPTS + "grade_word_to_definition_1.json",
            word=word,
            answer=answer,
        ),
        **options,
    )
    sense = _selected_sense(response, "defined_meaning", word["senses"])
    if sense is None:
        return DefinitionGrade(None, None, None)
    response = await model.decide(
        *render_decision(
            _PROMPTS + "grade_word_to_definition_2.json",
            word=word,
            selectedSense=sense,
            answer=answer,
        ),
        **options,
    )
    return DefinitionGrade(
        sense["id"],
        DefinitionAccuracy(response.choices["accuracy"].choice.upper()),
        DefinitionCoverage(response.choices["coverage"].choice.upper()),
    )


async def _usage(model, word, meaning, answer, config, options, source=None):
    response = await model.decide(
        *render_decision(_PROMPTS + "grade_word_to_usage_1.json", word=word, answer=answer),
        **options,
    )
    if not config.accepts(response.nouls["used"].noul):
        if source is not None:
            return RewriteGrade(False, None, None, None, None, None, None)
        return UsageGrade(False, None, None, None, None, None)
    response = await model.decide(
        *render_decision(
            _PROMPTS + "grade_word_to_usage_2.json",
            word=word,
            meaning=meaning,
            answer=answer,
            source=source,
        ),
        **options,
    )
    fields = (
        True,
        UsageMeaning(response.choices["meaning"].choice.upper()),
        UsageForm(response.choices["form"].choice.upper()),
        config.accepts(response.nouls["construction"].noul),
        config.accepts(response.nouls["collocation"].noul),
        config.accepts(response.nouls["appropriacy"].noul),
    )
    if source is not None:
        return RewriteGrade(
            *fields, MeaningPreservation(response.choices["meaning_preservation"].choice.upper())
        )
    return UsageGrade(*fields)


async def grade_answer(
    db,
    decision_model,
    question_artifact_id,
    question_type,
    fmt,
    answer,
    *,
    config: DecisionConfig,
    mode: DecisionMode = DecisionMode.LLM_FALLBACK,
    allowed_pairs=None,
):
    mode = DecisionMode(mode)
    kind, fmt = QuestionType(question_type), ResponseFormat(fmt)
    artifact = await get_artifact(db, question_artifact_id)
    if artifact is None:
        raise QuestionArtifactNotFoundError("Unknown QuestionArtifact")
    if (
        QUESTION_ARTIFACT_MAP[kind] != artifact.artifact_type
        or fmt is ResponseFormat.SINGLE_CHOICE
        or (kind, fmt) not in ALLOWED_PAIRS
        or (allowed_pairs is not None and (kind, fmt) not in allowed_pairs)
    ):
        raise UnsupportedQuestionFormatError("Unsupported artifact/type/format")
    if answer is None:
        if fmt == ResponseFormat.SINGLE_WORD:
            return SingleWordGrade(False, False, None)
        if kind == QuestionType.WORD_TO_DEFINITION:
            return DefinitionGrade(None, None, None)
        if kind == QuestionType.SENTENCE_REWRITE:
            return RewriteGrade(False, None, None, None, None, None, None)
        return UsageGrade(False, None, None, None, None, None)
    if not isinstance(answer, str) or not answer.strip() or len(answer) > MAX_TEXT_LENGTH:
        raise InvalidResourceError("Invalid answer")
    async with db.read() as connection:
        facts = (
            await connection.execute(
                select(row.Word.lemma, row.Definition.content)
                .join(row.Sense, row.Sense.word_id == row.Word.id)
                .join(row.Definition, row.Definition.sense_id == row.Sense.id)
                .where(
                    row.Sense.id == artifact.sense_id, row.Definition.theme_id == artifact.theme_id
                )
            )
        ).one_or_none()
    if facts is None:
        raise InvalidResourceError("Artifact's Sense definition is unavailable")
    word = SimpleNamespace(lemma=facts.lemma)
    sense = SimpleNamespace(definition=SimpleNamespace(content=facts.content))
    content = (
        sense.definition.content
        if kind == QuestionType.DEFINITION_TO_WORD
        else artifact.payload.get("context", word.lemma)
    )
    question = SimpleNamespace(sense_id=artifact.sense_id, question_type=kind, content=content)
    if fmt == ResponseFormat.SINGLE_WORD:
        correct = (
            artifact.payload["correct"]["expression"]
            if kind == QuestionType.CLOZE_TO_WORD
            else word.lemma
        )
        if answer_key(answer) == answer_key(correct):
            return SingleWordGrade(True, False, artifact.sense_id)
    if decision_model is None:
        raise MissingProviderError("Typed grading requires a decision provider")
    options = {"mode": mode}
    if fmt == ResponseFormat.SINGLE_WORD:
        return await _single_word(db, decision_model, question, answer, config, options)
    if kind == QuestionType.WORD_TO_DEFINITION:
        return await _definition(db, decision_model, question, answer, options)
    return await _usage(
        decision_model,
        {"lemma": word.lemma},
        sense.definition.content,
        answer,
        config,
        options,
        artifact.payload["source"] if kind == QuestionType.SENTENCE_REWRITE else None,
    )
