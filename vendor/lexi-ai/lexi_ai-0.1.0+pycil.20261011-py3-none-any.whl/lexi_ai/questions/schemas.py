"""Six artifact payload contracts and lexical validation."""

import re
from typing import Annotated

from pydantic import BaseModel, ConfigDict, Field, model_validator

from lexi_ai.errors import InvalidOutputError
from lexi_ai.models import Sense, Word
from lexi_ai.patterns import matches_pattern
from lexi_ai.text import answer_key, parse_marked_example, strip_markup
from lexi_ai.vocab import QuestionArtifactType

Text = Annotated[str, Field(min_length=1, max_length=8000)]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


class WordDefinitionPair(Strict):
    word: Text
    definition: Text


class WordDefinitionArtifact(Strict):
    corrects: list[Text]
    distractors: list[WordDefinitionPair]


class UsageArtifact(Strict):
    corrects: list[Text]
    distractors: list[Text]


class ContextPair(Strict):
    expression: Text
    meaning: Text


class ContextWordMeaningArtifact(Strict):
    context: Text
    correct: ContextPair
    distractors: list[ContextPair] = Field(min_length=1)


class ContextToWordArtifact(Strict):
    context: Text
    distractors: list[Text] = Field(min_length=1)


class CompletionPoint(Strict):
    turn_index: Annotated[int, Field(strict=True, ge=0)]
    distractors: list[Text] = Field(min_length=1)


class DialogueArtifact(Strict):
    conversation: list[dict[str, Text]] = Field(min_length=4)
    completion_points: list[CompletionPoint] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_turns(self):
        if any(len(turn) != 1 or not next(iter(turn)).strip() for turn in self.conversation):
            raise ValueError("Each turn must map one speaker name to its message")
        indices = [point.turn_index for point in self.completion_points]
        if len(set(indices)) != len(indices) or any(i >= len(self.conversation) for i in indices):
            raise ValueError("Invalid or repeated completion point")
        return self


class RewriteArtifact(Strict):
    source: Text
    correct: Text
    distractors: list[Text] = Field(min_length=1)


ARTIFACT_SCHEMAS = {
    QuestionArtifactType.WORD_DEFINITION: WordDefinitionArtifact,
    QuestionArtifactType.WORD_TO_USAGE: UsageArtifact,
    QuestionArtifactType.CONTEXT_WORD_MEANING: ContextWordMeaningArtifact,
    QuestionArtifactType.CONTEXT_TO_WORD: ContextToWordArtifact,
    QuestionArtifactType.DIALOGUE_COMPLETION: DialogueArtifact,
    QuestionArtifactType.SENTENCE_REWRITE: RewriteArtifact,
}


def _distinct(texts):
    keys = [answer_key(strip_markup(text)) for text in texts]
    if len(set(keys)) != len(keys):
        raise InvalidOutputError("Repeated artifact options")


def _components(surface: str) -> tuple[str, ...]:
    """Keep fixed components ordered, excluding citation slots, not their literal counterparts."""
    return tuple(answer_key(re.sub(r"\{[^{}]+\}", " ", surface)).split())


def _target_sequences(word: Word, sense: Sense) -> set[tuple[str, ...]]:
    sequences = {_components(surface) for surface in [word.lemma, *word.aliases]}
    base = _components(word.lemma)
    for form in sense.forms:
        components = _components(form.surface)
        sequences.add(
            components if len(base) == 1 or len(components) > 1 else components + base[1:]
        )
    return sequences


def _validate_marked_target(text: str, sequences: set[tuple[str, ...]], *, required: bool) -> int:
    _, spans = parse_marked_example(text)
    if not spans:
        if required:
            raise InvalidOutputError("target expression is not marked")
        return 0
    tokens = tuple(token for span in spans for token in answer_key(span.surface).split())
    # Multiple occurrences are allowed, but each must preserve all fixed components in order.
    positions = {0: 0}
    for start in range(len(tokens)):
        if start in positions:
            for sequence in sequences:
                if sequence and tokens[start : start + len(sequence)] == sequence:
                    end = start + len(sequence)
                    positions[end] = min(positions.get(end, len(tokens)), positions[start] + 1)
    if len(tokens) not in positions:
        raise InvalidOutputError("tags do not mark a complete licensed target expression")
    return positions[len(tokens)]


def _reveals_target(text: str, sequences: set[tuple[str, ...]]) -> bool:
    text = answer_key(text)
    return any(
        re.search(r"(?<!\w)" + r"\s+".join(map(re.escape, sequence)) + r"(?!\w)", text)
        for sequence in sequences
        if sequence
    )


def validate_artifact(payload, kind, word, sense, distractor_count, correct_count):
    sequences = _target_sequences(word, sense)

    def marked(text):
        _validate_marked_target(text, sequences, required=True)

    def hidden(text):
        if parse_marked_example(text)[1] or _reveals_target(text, sequences):
            raise InvalidOutputError("Source/context reveals the target")

    if kind == QuestionArtifactType.WORD_DEFINITION:
        if len(payload.corrects) != correct_count or len(payload.distractors) != distractor_count:
            raise InvalidOutputError("Incomplete singleton increment")
        _distinct(payload.corrects + [p.definition for p in payload.distractors])
        _distinct([p.word for p in payload.distractors])
        if any(_components(p.word) in sequences for p in payload.distractors):
            raise InvalidOutputError("Distractor repeats a target form or alias")
    elif kind == QuestionArtifactType.WORD_TO_USAGE:
        if len(payload.corrects) != correct_count or len(payload.distractors) != distractor_count:
            raise InvalidOutputError("Incomplete singleton increment")
        _distinct(payload.corrects + payload.distractors)
        for text in payload.corrects + payload.distractors:
            marked(text)
    elif kind == QuestionArtifactType.CONTEXT_WORD_MEANING:
        if payload.context.count("_") != 1:
            raise InvalidOutputError("Context needs exactly one blank")
        hidden(payload.context)
        head, _, tail = answer_key(word.lemma).partition(" ")
        forms = {
            head: [
                first
                for first, _, rest in (
                    answer_key(form.surface).partition(" ") for form in sense.forms
                )
                if not rest or rest == tail
            ]
        }
        patterns = [word.lemma, *word.aliases, *sense.patterns] + [
            form.surface
            for form in sense.forms
            if len(_components(form.surface)) >= len(_components(word.lemma))
        ]
        if not any(matches_pattern(p, payload.correct.expression, forms=forms) for p in patterns):
            raise InvalidOutputError("Correct expression is not a licensed target")
        _distinct([payload.correct.expression] + [p.expression for p in payload.distractors])
        _distinct([payload.correct.meaning] + [p.meaning for p in payload.distractors])
    elif kind == QuestionArtifactType.CONTEXT_TO_WORD:
        hidden(payload.context)
        if "_" in payload.context:
            raise InvalidOutputError("Situation cannot be a blank passage")
        _distinct([word.lemma] + payload.distractors)
        if any(_components(text) in sequences for text in payload.distractors):
            raise InvalidOutputError("Distractor repeats a target form or alias")
    elif kind == QuestionArtifactType.SENTENCE_REWRITE:
        hidden(payload.source)
        _distinct([payload.correct] + payload.distractors)
        for text in [payload.correct] + payload.distractors:
            marked(text)
    elif kind == QuestionArtifactType.DIALOGUE_COMPLETION:
        texts = [next(iter(turn.values())) for turn in payload.conversation]
        if sum(_validate_marked_target(t, sequences, required=False) for t in texts) != 1:
            raise InvalidOutputError("Conversation must contain one marked target")
        for point in payload.completion_points:
            original = texts[point.turn_index]
            _distinct([original] + point.distractors)
            for text in point.distractors:
                if parse_marked_example(original)[1]:
                    marked(text)
                elif parse_marked_example(text)[1]:
                    raise InvalidOutputError("Non-target replacement must not add target markup")
            if len(point.distractors) != distractor_count:
                raise InvalidOutputError("Incomplete completion point")
    if kind not in {
        QuestionArtifactType.WORD_DEFINITION,
        QuestionArtifactType.WORD_TO_USAGE,
        QuestionArtifactType.DIALOGUE_COMPLETION,
    }:
        if len(payload.distractors) != distractor_count:
            raise InvalidOutputError("Incomplete distractor bank")
