"""Append and retrieve trusted full QuestionArtifacts by exact namespace."""

import hashlib
import random
from copy import deepcopy
from dataclasses import replace

import orjson
from sqlalchemy import Integer, column, delete, func, literal, select, tuple_, values

from lexi_ai import schema as row
from lexi_ai.db.bulk import insert_identified_rows
from lexi_ai.db.collections import JsonObject, collection
from lexi_ai.db.pagination import validate_page
from lexi_ai.db.random import last_position, random_position
from lexi_ai.errors import InvalidResourceError, QuestionArtifactBankChangedError
from lexi_ai.models import QuestionArtifact, Word
from lexi_ai.schema import QuestionArtifact as ArtifactRow
from lexi_ai.text import answer_key, strip_markup
from lexi_ai.themes.namespace import theme_scope
from lexi_ai.vocab import SINGLETON_ARTIFACT_TYPES, GenerationState, QuestionArtifactType
from lexi_ai.words.storage import aliases, sense_fields, sense_view


def _dto(record) -> QuestionArtifact:
    from .schemas import ARTIFACT_SCHEMAS

    kind = QuestionArtifactType(record.artifact_type)
    payload = ARTIFACT_SCHEMAS[kind].model_validate(orjson.loads(record.payload)).model_dump()
    return QuestionArtifact(record.id, record.sense_id, record.theme_id, kind, payload)


def _payload(payload):
    encoded = orjson.dumps(payload, option=orjson.OPT_SORT_KEYS).decode()
    return encoded, hashlib.sha256(encoded.encode()).hexdigest()


async def append(db, artifacts: list[QuestionArtifact]) -> list[QuestionArtifact]:
    if not artifacts:
        return []
    artifacts = deepcopy(artifacts)
    from .schemas import ARTIFACT_SCHEMAS

    for artifact in artifacts:
        ARTIFACT_SCHEMAS[artifact.artifact_type].model_validate(artifact.payload)
    async with db.transaction(immediate=True) as session:
        sense_ids = sorted({a.sense_id for a in artifacts})
        if session.bind.dialect.name == "postgresql":
            await session.execute(
                select(row.Sense.id)
                .where(row.Sense.id.in_(sense_ids))
                .order_by(row.Sense.id)
                .with_for_update()
            )

        def scope(a):
            return a.sense_id, a.theme_id or 0, a.artifact_type

        singletons = [a for a in artifacts if a.artifact_type in SINGLETON_ARTIFACT_TYPES]
        scopes = {scope(a) for a in singletons}
        existing = (
            {
                (r.sense_id, r.theme_id or 0, r.artifact_type): r
                for r in (
                    await session.scalars(
                        select(ArtifactRow).where(
                            tuple_(
                                ArtifactRow.sense_id,
                                func.coalesce(ArtifactRow.theme_id, 0),
                                ArtifactRow.artifact_type,
                            ).in_(scopes)
                        )
                    )
                ).all()
            }
            if scopes
            else {}
        )
        saved, pending, pending_artifacts = [], [], []
        increments = {}
        for artifact in singletons:
            key = scope(artifact)
            if key not in increments:
                increments[key] = (
                    artifact,
                    orjson.loads(existing[key].payload)
                    if key in existing
                    else {"corrects": [], "distractors": []},
                )
            payload = increments[key][1]
            paired = artifact.artifact_type == QuestionArtifactType.WORD_DEFINITION

            def key_text(value):
                return answer_key(strip_markup(value))

            texts = {key_text(v) for v in payload["corrects"]}
            texts.update(key_text(v["definition"] if paired else v) for v in payload["distractors"])
            words = {key_text(v["word"]) for v in payload["distractors"]} if paired else set()
            for field in ("corrects", "distractors"):
                for value in artifact.payload[field]:
                    pair = paired and field == "distractors"
                    identity = key_text(value["definition"] if pair else value)
                    word = key_text(value["word"]) if pair else None
                    if identity in texts or word in words:
                        continue
                    payload[field].append(value)
                    texts.add(identity)
                    if pair:
                        words.add(word)
        for key, (artifact, payload) in increments.items():
            if not payload["corrects"] or not payload["distractors"]:
                raise InvalidResourceError("Singleton bank needs both answer arrays")
            encoded, fingerprint = _payload(payload)
            if key in existing:
                record = existing[key]
                record.payload, record.payload_hash = encoded, fingerprint
                saved.append(replace(artifact, id=record.id, payload=payload))
            else:
                pending.append(
                    dict(
                        sense_id=artifact.sense_id,
                        theme_id=artifact.theme_id,
                        artifact_type=artifact.artifact_type,
                        payload=encoded,
                        payload_hash=fingerprint,
                    )
                )
                pending_artifacts.append(replace(artifact, payload=payload))
        contextual = [
            (a, *_payload(a.payload))
            for a in artifacts
            if a.artifact_type not in SINGLETON_ARTIFACT_TYPES
        ]
        identities = [
            (a.sense_id, a.theme_id or 0, a.artifact_type, fingerprint)
            for a, _, fingerprint in contextual
        ]
        seen = (
            set(
                (
                    await session.execute(
                        select(
                            ArtifactRow.sense_id,
                            func.coalesce(ArtifactRow.theme_id, 0),
                            ArtifactRow.artifact_type,
                            ArtifactRow.payload_hash,
                        ).where(
                            tuple_(
                                ArtifactRow.sense_id,
                                func.coalesce(ArtifactRow.theme_id, 0),
                                ArtifactRow.artifact_type,
                                ArtifactRow.payload_hash,
                            ).in_(identities)
                        )
                    )
                ).all()
            )
            if identities
            else set()
        )
        for (artifact, encoded, fingerprint), identity in zip(contextual, identities, strict=True):
            if identity in seen:
                continue
            seen.add(identity)
            pending.append(
                dict(
                    sense_id=artifact.sense_id,
                    theme_id=artifact.theme_id,
                    artifact_type=artifact.artifact_type,
                    payload=encoded,
                    payload_hash=fingerprint,
                )
            )
            pending_artifacts.append(artifact)
        identifiers = await insert_identified_rows(session, ArtifactRow, pending)
        saved.extend(replace(a, id=i) for a, i in zip(pending_artifacts, identifiers, strict=True))
    cache = db.question_artifact_cache
    if cache is not None:
        for artifact in saved:
            cache.discard(artifact.id)
    return saved


async def get(db, question_id: int) -> QuestionArtifact | None:
    records = await get_many(db, [question_id])
    return records[0] if records else None


async def get_many(db, question_ids: list[int]) -> list[QuestionArtifact]:
    """Hydrate only selected artifacts, preserving the supplied identity order."""
    identifiers = list(dict.fromkeys(question_ids))
    if not identifiers:
        return []
    cache = db.question_artifact_cache
    by_id = cache.get_many(identifiers, QuestionArtifact) if cache is not None else {}
    missing = [identifier for identifier in identifiers if identifier not in by_id]
    if not missing:
        return [by_id[identifier] for identifier in identifiers]
    async with db.read() as connection:
        for start in range(0, len(missing), 500):
            records = (
                await connection.execute(
                    select(ArtifactRow.__table__).where(
                        ArtifactRow.id.in_(missing[start : start + 500])
                    )
                )
            ).all()
            for record in records:
                artifact = _dto(record)
                by_id[record.id] = artifact
                if cache is not None:
                    cache.put(record.id, artifact)
    return [by_id[identifier] for identifier in identifiers if identifier in by_id]


async def list_for_sense(
    db,
    sense_id: int,
    artifact_type: QuestionArtifactType | None = None,
    theme_id: int | None = None,
    *,
    theme_key: str | None = None,
    after_id: int | None = None,
    limit: int | None = None,
) -> list[QuestionArtifact]:
    validate_page(limit, after_id)
    if artifact_type is not None:
        artifact_type = QuestionArtifactType(artifact_type)
    identifier, valid = theme_scope(theme_id, theme_key)
    stmt = select(ArtifactRow.id).where(
        ArtifactRow.sense_id == sense_id, ArtifactRow.theme_id == identifier
    )
    ordering = [ArtifactRow.theme_id]
    if artifact_type is not None:
        stmt = stmt.where(ArtifactRow.artifact_type == artifact_type)
        ordering.append(ArtifactRow.artifact_type)
    if after_id is not None:
        stmt = stmt.where(ArtifactRow.id > after_id)
    stmt = stmt.order_by(*ordering, ArtifactRow.id).limit(limit)
    return await _read_bank(db, stmt, valid)


async def list_for_senses(
    db,
    sense_ids: list[int],
    artifact_types: list[QuestionArtifactType] | None = None,
    theme_id: int | None = None,
    *,
    theme_key: str | None = None,
    limit_per_type: int = 8,
) -> list[QuestionArtifact]:
    if type(limit_per_type) is not int or limit_per_type < 1:
        raise ValueError("limit_per_type must be a positive integer")
    if artifact_types is not None:
        artifact_types = [QuestionArtifactType(kind) for kind in artifact_types]
    identifier, valid = theme_scope(theme_id, theme_key)
    if not sense_ids:
        async with db.read() as connection:
            record = (await connection.execute(select(valid))).first()
            if record and not record[0]:
                raise InvalidResourceError("unknown Theme")
        return []
    rn = (
        func.row_number()
        .over(
            partition_by=(ArtifactRow.sense_id, ArtifactRow.artifact_type),
            order_by=ArtifactRow.id,
        )
        .label("rn")
    )
    inner = select(ArtifactRow.id, ArtifactRow.sense_id, ArtifactRow.artifact_type, rn).where(
        ArtifactRow.sense_id.in_(sense_ids),
        ArtifactRow.theme_id == identifier,
    )
    if artifact_types is not None:
        inner = inner.where(ArtifactRow.artifact_type.in_(artifact_types))
    subq = inner.subquery("ranked")
    cols = [subq.c.id, subq.c.sense_id, subq.c.artifact_type]
    ranked_stmt = select(*cols).where(subq.c.rn <= limit_per_type)
    return await _read_bank(db, ranked_stmt, valid, order_by=("sense_id", "artifact_type", "id"))


async def count_for_senses(
    db,
    sense_ids: list[int],
    artifact_types: list[QuestionArtifactType] | None = None,
    *,
    theme_key: str | None = None,
) -> dict[tuple[int, QuestionArtifactType], int]:
    if artifact_types is not None:
        artifact_types = [QuestionArtifactType(kind) for kind in artifact_types]
    identifier, valid = theme_scope(None, theme_key)
    grouped = (
        select(
            ArtifactRow.sense_id, ArtifactRow.artifact_type, func.count().label("question_count")
        )
        .where(ArtifactRow.sense_id.in_(sense_ids), ArtifactRow.theme_id == identifier)
        .group_by(ArtifactRow.sense_id, ArtifactRow.artifact_type)
    )
    if artifact_types is not None:
        grouped = grouped.where(ArtifactRow.artifact_type.in_(artifact_types))
    bank = grouped.subquery("bank_counts")
    singleton = select(literal(1)).subquery("namespace")
    statement = (
        select(
            valid.label("theme_valid"), bank.c.sense_id, bank.c.artifact_type, bank.c.question_count
        )
        .select_from(singleton)
        .outerjoin(bank, literal(True))
    )
    async with db.read() as connection:
        records = (await connection.execute(statement)).all()
    if not records[0].theme_valid:
        raise InvalidResourceError("unknown Theme")
    return {
        (record.sense_id, QuestionArtifactType(record.artifact_type)): record.question_count
        for record in records
        if record.sense_id is not None
    }


async def _read_bank(db, statement, valid, *, order_by=("id",)):
    # A left-join sentinel validates Theme even when the requested bank is empty.
    # It carries no artifact and is never deserialized as an artifact.
    bank = statement.subquery("bank")
    singleton = select(literal(1)).subquery("namespace")
    statement = (
        select(valid.label("theme_valid"), bank.c.id)
        .select_from(singleton)
        .outerjoin(bank, literal(True))
        .order_by(*(bank.c[name] for name in order_by))
    )
    async with db.read() as connection:
        records = (await connection.execute(statement)).all()
    if not records[0].theme_valid:
        raise InvalidResourceError("unknown Theme")
    return await get_many(db, [record.id for record in records if record.id is not None])


async def retrieve(
    db,
    sense_id: int,
    artifact_type: QuestionArtifactType | None = None,
    theme_id: int | None = None,
    *,
    theme_key: str | None = None,
) -> QuestionArtifact | None:
    if artifact_type is not None:
        artifact_type = QuestionArtifactType(artifact_type)
    identifier, valid = theme_scope(theme_id, theme_key)
    maximum = ArtifactRow.__table__.alias("last_question")
    slot = ArtifactRow.position if artifact_type is None else ArtifactRow.type_position
    max_slot = maximum.c.position if artifact_type is None else maximum.c.type_position
    scope = [ArtifactRow.sense_id == sense_id, ArtifactRow.theme_id == identifier]
    max_scope = [maximum.c.sense_id == sense_id, maximum.c.theme_id == identifier]
    if artifact_type is not None:
        scope.append(ArtifactRow.artifact_type == artifact_type)
        max_scope.append(maximum.c.artifact_type == artifact_type)
    chosen = random_position(maximum, max_slot, *max_scope, scope_order=(maximum.c.theme_id,))
    records = await _read_bank(
        db, select(ArtifactRow.id).where(*scope, slot == chosen).limit(1), valid
    )
    return records[0] if records else None


async def remove(db, question_id: int) -> bool:
    async with db.transaction() as session:
        result = await session.execute(delete(ArtifactRow).where(ArtifactRow.id == question_id))
        removed = bool(result.rowcount)
    cache = db.question_artifact_cache
    if cache is not None:
        cache.discard(question_id)
    return removed


async def bank_sizes(db, requests, *, theme_key=None):
    identifier, valid = theme_scope(None, theme_key)
    result = {}
    async with db.read() as connection:
        if not requests:
            if not await connection.scalar(select(valid)):
                raise InvalidResourceError("unknown Theme")
        for start in range(0, len(requests), 500):
            banks = (
                values(column("sense_id", Integer), column("kind", ArtifactRow.artifact_type.type))
                .data(requests[start : start + 500])
                .cte("requested_banks")
            )
            size = last_position(
                ArtifactRow,
                ArtifactRow.type_position,
                ArtifactRow.sense_id == banks.c.sense_id,
                ArtifactRow.artifact_type == banks.c.kind,
                ArtifactRow.theme_id == identifier,
                scope_order=(ArtifactRow.theme_id,),
                correlate=(banks,),
            )
            records = (await connection.execute(select(valid, *banks.c, size))).all()
            if not records[0][0]:
                raise InvalidResourceError("unknown Theme")
            result.update(
                {
                    (sense_id, QuestionArtifactType(kind)): size or 0
                    for _, sense_id, kind, size in records
                }
            )
    return result


async def retrieve_many(db, requests, *, theme_key=None) -> list[QuestionArtifact]:
    """Sample dense bank slots in bulk, without loading unselected payloads."""
    requests = [(sense_id, QuestionArtifactType(kind), count) for sense_id, kind, count in requests]
    if any(type(count) is not int or count < 1 for _, _, count in requests):
        raise ValueError("Artifact quantity must be a positive integer")
    pairs = [(sense_id, kind) for sense_id, kind, _ in requests]
    if len(set(pairs)) != len(pairs):
        raise ValueError("request each Sense/type bank once")
    identifier, valid = theme_scope(None, theme_key)
    slots = []
    # The last dense slot is the bank size. Each scope is an indexed LIMIT 1,
    # not a full bank COUNT or an unselected payload read.
    async with db.read() as connection:
        if not requests:
            if not await connection.scalar(select(valid)):
                raise InvalidResourceError("unknown Theme")
            return []
        for start in range(0, len(requests), 500):
            banks = (
                values(
                    column("sense_id", Integer),
                    column("kind", ArtifactRow.artifact_type.type),
                    column("quantity", Integer),
                )
                .data(requests[start : start + 500])
                .cte("requested_banks")
            )
            size = last_position(
                ArtifactRow,
                ArtifactRow.type_position,
                ArtifactRow.sense_id == banks.c.sense_id,
                ArtifactRow.artifact_type == banks.c.kind,
                ArtifactRow.theme_id == identifier,
                scope_order=(ArtifactRow.theme_id,),
                correlate=(banks,),
            )
            records = (await connection.execute(select(valid, *banks.c, size))).all()
            if not records[0][0]:
                raise InvalidResourceError("unknown Theme")
            for _, sense_id, kind, quantity, size in records:
                if kind in SINGLETON_ARTIFACT_TYPES:
                    quantity = 1
                if (size or 0) < quantity:
                    raise QuestionArtifactBankChangedError(
                        "Artifact bank cannot satisfy the request"
                    )
                slots.extend(
                    (sense_id, kind, slot) for slot in random.sample(range(1, size + 1), quantity)
                )
    ids = []
    if slots:
        async with db.read() as connection:
            for start in range(0, len(slots), 500):
                ids.extend(
                    (
                        await connection.scalars(
                            select(ArtifactRow.id).where(
                                ArtifactRow.theme_id == identifier,
                                tuple_(
                                    ArtifactRow.sense_id,
                                    ArtifactRow.artifact_type,
                                    ArtifactRow.type_position,
                                ).in_(slots[start : start + 500]),
                            )
                        )
                    ).all()
                )
    artifacts = await get_many(db, ids)
    if len(artifacts) != len(slots):
        raise QuestionArtifactBankChangedError("Artifact bank changed during retrieval")
    return artifacts


async def generation_context(db, sense_id, theme_id=None, *, theme_key=None):
    """Only the selected Sense and lexical facts; no graph or sibling Sense loads."""
    identifier, valid = theme_scope(theme_id, theme_key)
    fields = sense_fields(identifier, relations=False)
    payload = JsonObject(*(part for key, value in fields.items() for part in (literal(key), value)))
    # Bundle the independently projected identity and Theme into one statement.
    data = collection(
        row.Word.__table__.join(row.Sense.__table__, row.Sense.word_id == row.Word.id),
        {
            "lemma": row.Word.lemma,
            "entry_type": row.Word.entry_type,
            "word_id": row.Word.id,
            "aliases": aliases(row.Word.id, correlate=(row.Word.__table__,)),
            "sense": payload,
        },
        row.Sense.id == sense_id,
        row.Word.generation_state == GenerationState.DONE,
        valid,
        order_by=(row.Sense.id,),
    )
    theme = (
        collection(
            row.Theme,
            {"id": row.Theme.id, "voice": row.Theme.voice, "diction": row.Theme.diction},
            row.Theme.id == identifier,
            order_by=(row.Theme.id,),
        )
        if theme_id is not None or theme_key is not None
        else literal(None)
    )
    async with db.read() as connection:
        theme_valid, values, themes = (await connection.execute(select(valid, data, theme))).one()
    if not theme_valid:
        raise InvalidResourceError("unknown Theme")
    if not values:
        raise InvalidResourceError("unknown or unpublished Sense")
    value = values[0]
    sense = sense_view(value["sense"])
    if sense.definition is None or (
        (theme_id is not None or theme_key is not None) and not sense.examples
    ):
        raise InvalidResourceError("Sense content unavailable in requested namespace")
    word = Word(
        value["word_id"],
        value["lemma"],
        value["entry_type"],
        GenerationState.DONE,
        senses=[sense],
        aliases=[item["content"] for item in value["aliases"]],
    )
    return word, sense, themes[0] if themes else None
